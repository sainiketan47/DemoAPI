//
//  UsersCollectionViewCell.swift
//  Demo
//
//  Created by Ketan Saini on 08/01/18.
//  Copyright © 2018 Ketan Saini. All rights reserved.
//

import UIKit

class UsersCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var imgViewUserPic: UIImageView!
    @IBOutlet weak var lblName: UILabel!
    
}
