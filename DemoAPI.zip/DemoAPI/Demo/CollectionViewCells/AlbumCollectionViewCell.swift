//
//  AlbumCollectionViewCell.swift
//  Demo
//
//  Created by Ketan Saini on 08/01/18.
//  Copyright © 2018 Ketan Saini. All rights reserved.
//

import UIKit

class AlbumCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var imgViewAlbumPic: UIImageView!
    
}
